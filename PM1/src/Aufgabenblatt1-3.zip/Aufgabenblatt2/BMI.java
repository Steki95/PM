package Aufgabenblatt2;

import java.util.Scanner;

public class BMI {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		double Hohe,Gewicht;
		int BMI;
		System.out.println("Bitte geben sie die Hohe in cm ein: ");
		Hohe = input.nextDouble();
		System.out.println("Bitte geben sie jetz das Gewicht in kg: ");
		Gewicht = input.nextDouble();
		BMI = (int) (Gewicht/((Hohe/100)*2));
		System.out.println("Der BMI ist : "+BMI);
		input.close();
	}
}
