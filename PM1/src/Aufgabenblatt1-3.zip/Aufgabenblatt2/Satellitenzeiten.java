package Aufgabenblatt2;

import java.util.Scanner;

public class Satellitenzeiten {
	public static void main(String[] args){
		int d,h,m,s;
		Scanner input = new Scanner(System.in);
		System.out.println("Bitte geben sie die zeit in sekunden an: ");
		s = input.nextInt();
		m = s/60;
		h = m/60;
		d = h/24;
		s %=60;
		m %=60;
		h %=24; 
		System.out.println(d+" Tage "+h+":"+m+":"+s);
		input.close();
	}
}
