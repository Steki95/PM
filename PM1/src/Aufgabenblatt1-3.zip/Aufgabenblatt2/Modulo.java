package Aufgabenblatt2;

import java.util.Scanner;

public class Modulo {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		int a,b,formel,modul;
		System.out.println("Bitte geben sie a ein: ");
		a = input.nextInt();
		System.out.println("Bitte geben sie b ein: ");
		b = input.nextInt();
		modul = a%b;
		formel = a-(a/b)*b;
		System.out.println("Die formel L�sung ist : "+formel+", die modul L�sung ist: "+modul);
		input.close();
	}
}

