package Aufgabenblatt3;

import java.util.Scanner;

public class Fl�cheninhalt {
	public static double Kreis(double x){
		return Math.pow(x,2)*Math.PI;
	}
	public static double Quadrat(double x){
		return x*x;
	}
	public static double Sechsek(double x){
		return 6*(Math.pow(x, 2)*Math.sqrt(3)/4);
	}
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		int index;
		double x,A;
		System.out.println("Geben Sie den index ein(1-Kreis,2-Quadrat,3-Sechseck): ");
		index = input.nextInt();
		System.out.println("Geben Sie x ein: ");
		x = input.nextDouble();
		
		switch(index){
		
			case 1:A=Kreis(x);break;
			case 2:A=Quadrat(x);break;
			case 3:A=Sechsek(x);break;
		}
		
		if(index == 1)
			A=Kreis(x);
		else if(index == 2)
			A=Quadrat(x);
		else
			A=Sechsek(x);
		
		System.out.println("Die Flache ist: "+A);
		input.close();
	}
}
