package Aufgabenblatt3;

import java.util.Scanner;

public class Fibonacci {
	public static int fibonacci(int x){
		if(x == 1 || x == 2)
			return 1;
			return fibonacci(x-1)+fibonacci(x-2);
	}
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		int index,a,b,swap,zahler;
		System.out.println("Geben sie welche zahl sie finden wohlen: ");
		index = input.nextInt();
		a=1;
		b=1;
		zahler = index;
		swap = 0;
		while(zahler>1){
			swap=a+b;
			a=b;
			b=swap;
			zahler--;
		}
		System.out.println("Die "+index+" Zahl ist "+a);
		input.close();
	}
}
